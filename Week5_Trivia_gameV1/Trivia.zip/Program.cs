﻿using System;
using static System.Console;

namespace Week5_Trivia_game
{
    class Program
    {
        static void Main(string[] args)
        {

            Game game = new Game();
            

        }
    }
}
