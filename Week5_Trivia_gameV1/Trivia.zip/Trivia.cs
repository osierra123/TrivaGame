﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Week5_Trivia_game
{
    class Trivia
    {
        public string[] Question;
        public string [] Answer;
        public string[] Options;




    }
}
