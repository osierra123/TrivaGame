﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Week5_Trivia_game
{
    class Player
    {
        public string Name { get; set; }
        public int Score { get; set; } 
        public Player()
        {
            Score = 0; 

        }
    }
    
}
